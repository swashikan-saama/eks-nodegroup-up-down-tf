import boto3
import json
import os


def lambda_handler(event, context):
    # Replace with your actual AWS region and EKS cluster name
    AWS_REGION = os.environ['REGION']
    AWS_KEY = os.environ['KEY']
    AWS_VALUE = os.environ['VALUE']

    # Create a Boto3 EKS client
    eks_client = boto3.client("eks", region_name=AWS_REGION)

    # List all EKS clusters in the region
    clusters = eks_client.list_clusters()
    print("-------------------------")
    print("-------------------------")

    # Iterate through the clusters
    for cluster_name in clusters["clusters"]:
        # Describe the cluster to get its tags
        cluster_info = eks_client.describe_cluster(name=cluster_name)
        CLUSTER_NAME = cluster_info["cluster"]["name"]

        arn = cluster_info["cluster"]["arn"]
        resp2 = eks_client.list_tags_for_resource(resourceArn=arn)
    
        # Check if the EKS cluster has no tags
        if not resp2.get('tags'):
            print(f'EKS Cluster "{CLUSTER_NAME}" does not have any Cluster Tags')
            print("-------------------------")
            print("-------------------------")
        else:
            tags = resp2.get('tags', {})
            
            # Initialize flag variables
            key_found = False
            value_found = False

            # Iterate through the dictionary of tags
            for tag_key, tag_value in tags.items():
                if tag_key == AWS_KEY and tag_value == AWS_VALUE:
                    key_found = True
                    value_found = True
                    break

            if key_found == False and value_found == False:
                print(f'EKS Cluster "{CLUSTER_NAME}" is not a part of EKS-Automation Schedule')
                print("-------------------------")
                print("-------------------------")
                
            if key_found and value_found:
                print(f'EKS Cluster "{CLUSTER_NAME}" is a part of EKS-Automation Schedule')

                # Get the list of node group names in the EKS cluster
                nodegroup_names = eks_client.list_nodegroups(clusterName=CLUSTER_NAME)["nodegroups"]
            
                for nodegroup_name in nodegroup_names:
                    print("-------------------------")
            
                    print(f"Updating Node Group: {nodegroup_name}")
                         
                    # Describe the node group to get scaling information
                    nodegroup_info = eks_client.describe_nodegroup(clusterName=CLUSTER_NAME, nodegroupName=nodegroup_name)
                    nodegroup_arn = nodegroup_info["nodegroup"]["nodegroupArn"]
                    min_size = nodegroup_info["nodegroup"]["tags"]["MinSize"]
                    desired_size = nodegroup_info["nodegroup"]["tags"]["DesiredSize"]
                    min_size=int(min_size)
                    desired_size=int(desired_size)
                    print(f"Reupdated DesiredSize: {desired_size}")
                    print(f"Reupdated MinSize: {min_size}")
            
                    # Use the update_nodegroup_config method to set minSize and desiredSize
                    eks_client.update_nodegroup_config(
                        clusterName=CLUSTER_NAME,
                        nodegroupName=nodegroup_name,
                        scalingConfig={"minSize": min_size, "desiredSize": desired_size},
                    )
            
                    # print(f"Updated minSize and desiredSize to MinSize={min_size}, DesiredSize={desired_size} for Node Group: {nodegroup_name}")
                    print("-------------------------")
